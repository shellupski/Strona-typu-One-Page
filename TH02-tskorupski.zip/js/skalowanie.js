    $(document).ready(function() {
        $("body").ezBgResize({
            img : "img/bg3.jpg"
        });
    });